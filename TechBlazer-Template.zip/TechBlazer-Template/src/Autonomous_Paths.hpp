#ifndef AUTON_HPP
#define AUTON_HPP

#include "globals.hpp"

void redAuton1() {
    
}
void redAuton2() {
    
}
void blueAuton1() {
    
}
void blueAuton2() {
    
}

void exampleAuton() {
    
}
#endif